<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - School Management System</title>
    <style>
        /* General Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        /* Navbar Customizations */
        .navbar {
            background-color: #007bff;
            color: white;
            position: fixed;
            width: 100%;
            z-index: 10;
            top: 0;
            left: 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .navbar .navbar-brand {
            color: white !important;
        }

        .navbar .nav-link {
            color: white !important;
        }

        .navbar .nav-link.active {
            font-weight: bold;
            text-decoration: underline;
        }

        /* Add Login Button to top-right */
        .login-btn {
            position: absolute;
            top: 10px;
            right: 20px;
            border: 2px solid white;
            border-radius: 20px;
            padding: 5px 15px;
            transition: background-color 0.3s ease;
        }

        .login-btn:hover {
            background-color: #0056b3;
            cursor: pointer;
        }

        /* Hero Section */
        .hero-section {
            margin-top: 80px;
            text-align: center;
            padding: 60px 15px;
            background-color: #007bff;
            color: white;
            border-bottom: 5px solid #0056b3;
        }

        .hero-section h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
        }

        .hero-section p {
            font-size: 1.2rem;
            font-weight: 300;
        }

        /* Card Styles */
        .card {
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }

        .card-body {
            background-color: #e9ecef;
        }

        .card-body ul {
            padding-left: 0;
            list-style-type: none;
        }

        .card-body ul li {
            margin-bottom: 10px;
        }

        .toggle-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .toggle-btn:hover {
            background-color: #0056b3;
        }

        /* Footer Styling */
        footer {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: white;
            transition: background-color 0.3s ease;
        }

        footer:hover {
            background-color: #0056b3;
        }

        footer p {
            margin: 0;
        }

        /* Modal Customizations */
        .modal-content {
            border-radius: 15px;
        }

        .modal-header {
            background-color: #007bff;
            color: white;
        }

        .modal-footer button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .modal-footer button:hover {
            background-color: #0056b3;
        }

        /* Form Input Styling */
        .form-control {
            border-radius: 10px;
            padding: 12px;
            font-size: 1rem;
            margin-bottom: 15px;
        }

        /* Social Media Links */
        .social-links a {
            margin: 0 10px;
            transition: transform 0.3s ease;
        }

        .social-links a:hover {
            transform: scale(1.1);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.5rem;
            }
            .card {
                margin-bottom: 15px;
            }
            .login-btn {
                top: 15px;
                right: 15px;
            }
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="assets/images/school-logo.png" type="download/png"> <!-- Favicon for School -->
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">School Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="library.php">Library</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="labrotary.php">Laboratory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="administration.php">Administration</a>
                    </li>
                  
                </ul>
            </div>
        </div>
        <!-- Login Button -->
        <button class="btn btn-outline-light login-btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
    </nav>

    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loginModalLabel">Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="login.php">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="section" class="form-label">Section</label>
                            <input type="text" class="form-control" id="section" name="section" required>
                        </div>
                        <div class="mb-3">
                            <label for="rollno" class="form-label">Roll No</label>
                            <input type="text" class="form-control" id="rollno" name="rollno" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Hero Section -->
    <div class="hero-section">
        <h1>School Administration</h1>
        <p class="lead">Manage all aspects of school operations from one place.</p>
    </div>

    <!-- Administration Overview -->
    <div class="container mt-5">
        <section>
            <h2>Administration Modules</h2>
            <p>Our School Management System offers a range of powerful tools for streamlining administrative tasks.</p>
            <div class="row mt-5">
                <!-- Communication Tools -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">Communication Tools</div>
                        <div class="card-body">
                            <ul>
                                <li><strong>Internal Messaging:</strong> Communicate between staff, students, and parents.</li>
                                <li><strong>Announcement Boards:</strong> Post school-wide notices.</li>
                                <li><strong>Email/SMS Notifications:</strong> Send alerts and updates to stakeholders.</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Document Management -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">Document Management</div>
                        <div class="card-body">
                            <ul>
                                <li><strong>Student Records:</strong> Manage academic and health records.</li>
                                <li><strong>Staff Files:</strong> Store certifications and performance evaluations.</li>
                                <li><strong>Policy Manuals:</strong> Access school policies and administrative documents.</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Financial Management -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">Financial Management</div>
                        <div class="card-body">
                            <ul>
                                <li><strong>Fee Management:</strong> Automate fee calculation and payments.</li>
                                <li><strong>Budgeting & Accounting:</strong> Track and manage budgets.</li>
                                <li><strong>Payroll System:</strong> Handle staff salaries.</li>
                                <li><strong>Fundraising Tracker:</strong> Manage donations and fundraising activities.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="toggle-section mt-5">
                <button class="btn btn-info toggle-btn">Show More Details</button>
                <div class="toggle-content d-none">
                    <h4>Additional Features</h4>
                    <ul>
                        <li><strong>Course Registration:</strong> Allow students to register for classes.</li>
                        <li><strong>Attendance Tracking:</strong> Monitor student attendance across all classes.</li>
                        <li><strong>Performance Analytics:</strong> Visualize student and staff performance data.</li>
                        <li><strong>Event Management:</strong> Organize school events and extracurricular activities.</li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- Social Media Links -->
        <div class="social-links text-center mt-5">
            <h4>Follow us on Social Media:</h4>
            <a href="https://www.youtube.com" target="_blank" class="social-icon">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/YouTube_icon_%282013-2017%29.png/600px-YouTube_icon_%282013-2017%29.png" alt="YouTube" style="width: 40px;">
            </a>
            <a href="https://www.facebook.com" target="_blank" class="social-icon">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Facebook_Logo_2023.png/600px-Facebook_Logo_2023.png" alt="Facebook" style="width: 40px;">
            </a>
            <a href="https://www.instagram.com" target="_blank" class="social-icon">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/800px-Instagram_logo_2022.svg.png" alt="Instagram" style="width: 40px;">
            </a>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 School Management System | All Rights Reserved</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Toggle Content Display
        document.querySelector('.toggle-btn').addEventListener('click', function() {
            const content = document.querySelector('.toggle-content');
            content.classList.toggle('d-none');
            this.textContent = content.classList.contains('d-none') ? 'Show More Details' : 'Show Less';
        });
    </script>
</body>
</html>