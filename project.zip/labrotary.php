<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratory - School Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Your custom CSS file -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }

        nav.navbar {
            background-color: #007bff;
            padding: 1rem;
        }

        nav.navbar .navbar-brand {
            color: white;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: white !important;
            font-weight: 500;
        }

        .navbar-nav .nav-link:hover {
            color: #ffd700 !important;
        }

        .container {
            margin-top: 30px;
        }

        .text-center h1 {
            font-size: 36px;
            font-weight: bold;
            color: #007bff;
        }

        .feature-box {
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .feature-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .feature-box h3 {
            font-size: 24px;
            color: #007bff;
            margin-bottom: 10px;
        }

        .feature-box p {
            font-size: 16px;
            color: #6c757d;
            margin-bottom: 20px;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .row {
            display: flex;
            justify-content: center;
        }

        .col-md-4 {
            margin-bottom: 30px;
        }

        @media (max-width: 767px) {
            .container {
                margin-top: 15px;
            }

            .feature-box {
                margin-bottom: 20px;
            }

            .text-center h1 {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">School Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="library.php">Library</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="labrotary.php">Laboratory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="administration.php">Administration</a>
                    </li>
                 
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="text-center">
            <h1>Welcome to the Laboratory Section</h1>
            <p class="lead">Explore our various laboratory sections for experiments and resources.</p>
        </div>

        <!-- Laboratory Sections -->
        <div class="row mt-5">
            <!-- Physics Section -->
            <div class="col-md-4 text-center mb-4">
                <div class="feature-box">
                    <h3>Physics</h3>
                    <p>Explore experiments and resources related to physics.</p>
                    <a href="physics.php" class="btn btn-primary">Explore Physics</a>
                </div>
            </div>

            <!-- Chemistry Section -->
            <div class="col-md-4 text-center mb-4">
                <div class="feature-box">
                    <h3>Chemistry</h3>
                    <p>Explore experiments and resources related to chemistry.</p>
                    <a href="chemistry.php" class="btn btn-primary">Explore Chemistry</a>
                </div>
            </div>

            <!-- Computer Science Section -->
            <div class="col-md-4 text-center mb-4">
                <div class="feature-box">
                    <h3>Computer Science</h3>
                    <p>Explore experiments and resources related to computer science.</p>
                    <a href="computer.php" class="btn btn-primary">Explore Computer Science</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
