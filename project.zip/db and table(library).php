<?php
// create_db.php

$servername = "localhost";
$username   = "root";       // Change as needed
$password   = "";           // Change as needed

// Connect to MySQL server (without specifying a database)
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS library_school";
if ($conn->query($sql) === TRUE) {
    echo "Database 'library_school' created or already exists.<br>";
} else {
    die("Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db('library_school');

// Create 'books' table for storing book information
$sql = "CREATE TABLE IF NOT EXISTS books_school(
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    borrowed_date DATE,  /* New column to store borrowed date */
    submission_deadline DATE,  /* New column to store submission deadline */
    returned_date DATE,  /* Existing column to store returned date */
    fee DECIMAL(10, 2) NOT NULL DEFAULT 0,  /* Fee column */
    status ENUM('borrowed', 'returned') NOT NULL DEFAULT 'borrowed'  /* Status column for borrowed or returned books */
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'books_school' created or already exists.<br>";
} else {
    die("Error creating table 'books_school': " . $conn->error);
}

$conn->close();
echo "Database setup completed successfully!";
?>
