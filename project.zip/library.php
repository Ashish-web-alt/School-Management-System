<?php
// Database configuration

$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "library"; 

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library - School Management System</title>
    
    <style>
        



body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }

        nav.navbar {
            background-color: #007bff;
            padding: 1rem;
        }

        nav.navbar .navbar-brand {
            color: white;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: white !important;
            font-weight: 500;
        }

        .navbar-nav .nav-link:hover {
            color: #ffd700 !important;
        }
h2, h4 {
    color: #007bff;  /* Dark blue color for headings */
    font-weight: bold;
}

.container {
    max-width: 1200px;
    margin-top: 50px;
}

/* Card Styling for Borrowed and Returned Sections */
.card {
    border-radius: 10px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.card-header {
    font-size: 1.25rem;
    font-weight: bold;
    padding: 20px;
}

.card-body {
    padding: 20px;
}

.card-header.bg-primary {
    background-color: #007bff; /* Blue color */
}

.card-header.bg-success {
    background-color: #28a745; /* Green color */
}

.card-body .btn {
    font-size: 16px;
    padding: 12px 25px;
    border-radius: 50px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

.card-body .btn:hover {
    background-color: #0056b3; /* Darker blue on hover */
    transform: translateY(-2px);
}

/* Form Styling */
#borrowForm, #returnForm {
    background-color: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
    margin-top: 20px;
}

#borrowForm h4, #returnForm h4 {
    color: #007bff;
    margin-bottom: 20px;
}

.form-label {
    font-weight: bold;
}

.form-control {
    border-radius: 8px;
    border: 1px solid #ccc;
    box-shadow: none;
    margin-bottom: 15px;
    font-size: 16px;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    padding: 12px 30px;
    font-size: 16px;
    border-radius: 8px;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

.btn-success {
    background-color: #28a745;
    border-color: #28a745;
    padding: 12px 30px;
    font-size: 16px;
    border-radius: 8px;
}

.btn-success:hover {
    background-color: #218838;
    border-color: #1e7e34;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        margin-top: 20px;
    }
    .card-body .btn {
        font-size: 14px;
        padding: 10px 20px;
    }
    .form-control {
        font-size: 14px;
    }
    #borrowForm, #returnForm {
        padding: 20px;
    }
}

    </style>
</head>
<body background="image1.jpeg" width="100%" height="100%">
    
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">School Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="library.php">Library</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="labrotary.php">Laboratory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="administration.php">Administration</a>
                    </li>
                 
                </ul>
            </div>
        </div>
    </nav>

   

    <!-- Library Section -->
    <div class="container mt-5">
        <h2 class="text-center mb-4">Library Section</h2>
        <p class="text-center">Manage all the books, journals, and materials available in the library.</p>

        <!-- Borrowed and Returned Containers -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card border-primary mb-3">
                    <div class="card-header bg-primary text-white text-center">
                        <h5>Books Borrowed</h5>
                    </div>
                    <div class="card-body text-center">
                        <button class="btn btn-primary" id="showBorrowFormBtn">Click to Manage Borrowed Books</button>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card border-success mb-3">
                    <div class="card-header bg-success text-white text-center">
                        <h5>Books Returned</h5>
                    </div>
                    <div class="card-body text-center">
                        <button class="btn btn-success" id="showReturnFormBtn">Click to Manage Returned Books</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Borrowed Book Form (Initially Hidden) -->
        <div id="borrowForm" class="mt-4" style="display:none;">
            <h4 class="text-center">Borrowed Book Form</h4>
            <form action="library_records.php" method="POST">
                <div class="mb-3">
                    <label for="borrowedBook" class="form-label">Borrowed Book</label>
                    <input type="text" class="form-control" id="borrowedBook" name="borrowedBook"required>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" class="form-control" id="price" name="price" required>
                </div>
                <div class="mb-3">
                    <label for="borrowedDate" class="form-label">Borrowed Date</label>
                    <input type="date" class="form-control" id="borrowedDate" name="borrowedDate" required>
                </div>
                <div class="mb-3">
                    <label for="submissionDeadline" class="form-label">Deadline of Submission</label>
                    <input type="date" class="form-control" id="submissionDeadline" name="submissionDeadline" required>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>

    </div>
   <!-- Returned Book Form (Initially Hidden) -->
<div id="returnForm" class="mt-4" style="display:none;">
    <h4 class="text-center">Returned Book Form</h4>
    <form action="library_records.php" method="POST">
        <div class="mb-3">
            <label for="returnedBook" class="form-label">Returned Book Title</label>
            <input type="text" class="form-control" id="returnedBook" name="returnedBook" required>
        </div>
        <div class="mb-3">
            <label for="returnedPrice" class="form-label">Price</label>
            <input type="number" class="form-control" id="returnedPrice" name="returnedPrice" required>
        </div>
        <div class="mb-3">
            <label for="returnedDate" class="form-label">Returned Date</label>
            <input type="date" class="form-control" id="returnedDate" name="returnedDate" required>
        </div>
        <div class="mb-3">
            <label for="fee" class="form-label">Fee (if any)</label>
            <input type="number" class="form-control" id="fee" name="fee" required>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </form>
</div>


    <!-- Bootstrap JS, Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JavaScript -->
    <script>
        // JavaScript for showing the Borrowed Book Form
        document.getElementById("showBorrowFormBtn").addEventListener("click", function() {
            // Show the Borrowed Book form and hide the "Books Borrowed" container
            document.getElementById("borrowForm").style.display = "block";
            document.getElementById("returnForm").style.display = "none"; // Hide return form if visible
        });

        // JavaScript for showing the Returned Book Form
        document.getElementById("showReturnFormBtn").addEventListener("click", function() {
            // Show the Returned Book form and hide the "Books Returned" container
            document.getElementById("returnForm").style.display = "block";
            document.getElementById("borrowForm").style.display = "none"; // Hide borrow form if visible
        });
       

    </script>

</body>

    
</body>
</html>
