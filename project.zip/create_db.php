<?php
// create_db.php

$servername = "localhost";
$username   = "root";       // Change as needed
$password   = "";           // Change as needed

// Connect to MySQL server (without specifying a database)
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS login_user";
if ($conn->query($sql) === TRUE) {
    echo "Database 'login_user' created or already exists.<br>";
} else {
    die("Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db('login_user');
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    rollno VARCHAR(100) NOT NULL,
    section VARCHAR(100) NOT NULL
)";
if ($conn->query($sql) === TRUE) {
    echo "Table 'users' created or already exists.<br>";
} else {
    die("Error creating table 'users': " . $conn->error);
}

$conn->close();
echo "Database setup completed successfully!";
?>

