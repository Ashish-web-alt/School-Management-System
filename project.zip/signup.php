<?php
// Database credentials
$servername = "localhost";
$username = "root"; // Change as needed
$password = ""; // Change as needed
$dbname = "login_user"; // Change as needed

// Create a connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt the password
    $rollno = $conn->real_escape_string($_POST['rollno']);
    $section = $conn->real_escape_string($_POST['section']);

    // Insert data into users table
    $sql = "INSERT INTO users (username, password, rollno, section) VALUES ('$username', '$password', '$rollno', '$section')";

    if ($conn->query($sql) === TRUE) {
        echo "Sign-up successful!";
    } else {
        echo "Error: " . $conn->error;
    }
    
    // Close the connection
    $conn->close();
}
?>
