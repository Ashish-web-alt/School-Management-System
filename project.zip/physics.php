<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Physics - School Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }

        nav.navbar {
            background-color: #007bff;
            padding: 1rem;
        }

        nav.navbar .navbar-brand {
            color: white;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: white !important;
            font-weight: 500;
        }

        .navbar-nav .nav-link:hover {
            color: #ffd700 !important;
        }

        .container {
            margin-top: 30px;
        }

        h1 {
            text-align: center;
            font-size: 36px;
            font-weight: bold;
            color: #007bff;
        }

        .teachers-section {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-top: 40px;
        }

        .teacher-card {
            background-color: #ffffff;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 220px;
            padding: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .teacher-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }

        .teacher-card img {
            width: 100%;
            height: 150px;
            border-radius: 8px;
            object-fit: cover;
        }

        .teacher-card h5 {
            margin-top: 15px;
            color: #007bff;
            font-size: 18px;
        }

        .teacher-card p {
            color: #6c757d;
            font-size: 16px;
        }

        @media (max-width: 767px) {
            .teacher-card {
                width: 100%;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">School Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="library.php">Library</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="labrotary.php">Laboratory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="physics.php">Physics</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="administration.php">Administration</a>
                    </li>
                   
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <h1>Our Physics Teachers</h1>
        
        <div class="teachers-section">
            <!-- Teacher 1 -->
            <div class="teacher-card">
                <img src="Screenshot (11).png" alt="">
                <h5>Mr. Rajib Chandra Belbase</h5>
                <p>Head of Physics Department</p>
            </div>

            <!-- Teacher 2 -->
            <div class="teacher-card">
                <img src="Screenshot (12).png" alt="">
                <h5>Mr. Dhanik Lal Kushwaha</h5>
                
            </div>

            <!-- Teacher 3 -->
            <div class="teacher-card">
                <img src="Screenshot (13).png" alt="">
                <h5>Mr. Niranjan Dahal</h5>
                
            </div>

            <!-- Teacher 4 -->
            <div class="teacher-card">
                <img src="Screenshot (16).png" alt="">
                <h5>Mr. Santosh Jirel</h5>
                
            </div>

            <!-- Teacher 5 -->
            <div class="teacher-card">
                <img src="Screenshot (17).png" alt="">
                <h5>Mr. Keshav Paudel</h5>
                
            </div>

          
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
