<?php
// Database configuration
$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "library_school"; 

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert borrowed book into database
if (isset($_POST['borrowedBook'])) {
    $title = $_POST['borrowedBook'];
    $price = $_POST['price'];
    $borrowedDate = $_POST['borrowedDate'];
    $submissionDeadline = $_POST['submissionDeadline'];
    $status = 'borrowed';  // Set the status as "borrowed"
    
    // Insert borrowed book into database
    $sql = "INSERT INTO books_school (title, price, borrowed_date, submission_deadline, returned_date, fee, status)
            VALUES ('$title', '$price', '$borrowedDate', '$submissionDeadline', NULL, 0, '$status')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New borrowed book record created successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


  // Insert returned book into database
if (isset($_POST['returnedBook'])) {
    $title = $_POST['returnedBook'];
    $price = $_POST['returnedPrice'];
    $returnedDate = $_POST['returnedDate'];
    $fee = $_POST['fee'];
    $status = 'returned';  // Set the status as "returned"
    
    // Insert returned book into database
    $sql = "UPDATE books_school SET returned_date = '$returnedDate', fee = '$fee', status = '$status'
            WHERE title = '$title' AND status = 'borrowed'";  // Assuming title is unique or otherwise identify the specific record
    
    if ($conn->query($sql) === TRUE) {
        echo "Book returned successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


// Display all books in tabular form
$sql = "SELECT * FROM books_school";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library - School Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Library Records</h2>

        <!-- Table to display all records -->
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Book Title</th>
                    <th>Price</th>
                    <th>Borrowed Date</th>
                    <th>Submission Deadline</th>
                    <th>Returned Date</th>
                    <th>Fee</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Check if there are any records to display
                if ($result->num_rows > 0) {
                    // Loop through each record and display it in a table row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>".$row['book_id']."</td>
                                <td>".$row['title']."</td>
                                <td>".$row['price']."</td>
                                 <td>".$row['borrowed_date']."</td>
                                  <td>".$row['submission_deadline']."</td>
                                <td>".$row['returned_date']."</td>
                                <td>".$row['fee']."</td>
                                <td>".$row['status']."</td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No records found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS, Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
