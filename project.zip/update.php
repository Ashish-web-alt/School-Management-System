<?php
// Database credentials
$servername = "localhost";
$username = "root";  // Change as needed
$password = "";       // Change as needed
$dbname = "login_user";  // Change as needed

// Create a connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If there is an ID in the query string, fetch the corresponding user's data
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Query to fetch user data by ID
    $sql = "SELECT * FROM users WHERE id = $user_id";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // Fetch user data
        $row = $result->fetch_assoc();
    } else {
        echo "No user found with that ID.";
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve data from the form
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt the password
    $rollno = $conn->real_escape_string($_POST['rollno']);
    $section = $conn->real_escape_string($_POST['section']);

    // Update the user data in the database
    $sql = "UPDATE users SET username = ?, password = ?, rollno = ?, section = ? WHERE id = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssssi", $username, $password, $rollno, $section, $user_id);
        if ($stmt->execute()) {
            echo "Record updated successfully!";
            header("Location: show_records.php");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Update User Information</h1>

        <form method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?= $row['username']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="mb-3">
                <label for="rollno" class="form-label">Roll No</label>
                <input type="text" class="form-control" id="rollno" name="rollno" value="<?= $row['rollno']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="section" class="form-label">Section</label>
                <input type="text" class="form-control" id="section" name="section" value="<?= $row['section']; ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
