<?php
// Database credentials
$servername = "localhost";
$username = "root";  // Change as needed
$password = "";       // Change as needed
$dbname = "login_user";  // Change as needed

// Create a connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If there is an ID in the query string, delete the corresponding user record
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Prepare the SQL DELETE query
    $sql = "DELETE FROM users WHERE id = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo "Record deleted successfully!";
            header("Location: show_records.php");
            exit();
        } else {
            echo "Error deleting record: " . $conn->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>
