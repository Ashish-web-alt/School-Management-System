<?php 
// Database credentials
$servername = "localhost";
$username = "root";  // Change as needed
$password = "";       // Change as needed
$dbname = "login_user";  // Change as needed

// Create a connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize user inputs
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];  // No need to escape password, since it's hashed
    $rollno = $conn->real_escape_string($_POST['rollno']);
    $section = $conn->real_escape_string($_POST['section']);

    // Prepare the SQL query to check if the user exists
    $sql = "SELECT * FROM users WHERE username = ? AND rollno = ? AND section = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters to the prepared statement
        $stmt->bind_param("sss", $username, $rollno, $section);
        
        // Execute the query
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User exists, now verify password
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                header("Location: show_records.php");
                exit(); // Always call exit() after header redirection
            } else {
                echo "Incorrect password.";
            }
        } else {
            echo "Please sign up first.";
        }
        
        // Close the statement
        $stmt->close();
    } else {
        echo "Error in query: " . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>
