<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System</title>
    <style>
           /* Add some custom styles for the Signup Button */
           .signup-btn {
            position: absolute;
            top: 10px;
            right: 20px;
            border: 2px solid white;
            border-radius: 20px;
            padding: 5px 15px;
            transition: background-color 0.3s ease;
        }

        .signup-btn:hover {
            background-color: #28a745;
            cursor: pointer;
        }

        /* Modal Styling */
        .modal-content {
            border-radius: 15px;
        }

        .modal-header {
            background-color: #28a745;
            color: white;
        }

        .modal-footer button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
        }

        .modal-footer button:hover {
            background-color: #218838;
        }

        /* Form Input Styling */
        .form-control {
            border-radius: 10px;
            padding: 12px;
            font-size: 1rem;
            margin-bottom: 15px;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">School Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="library.php">Library</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="labrotary.php">Laboratory</a>
                    </li>
                  
                  
                </ul>
            </div>
        </div>
    </nav>
      <!-- Signup Button (top-right corner) -->
      <button class="btn btn-outline-light signup-btn" data-bs-toggle="modal" data-bs-target="#signupModal">Sign Up</button>

      <!-- Signup Modal -->
      <div class="modal fade" id="signupModal" tabindex="-1" aria-labelledby="signupModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title" id="signupModalLabel">Sign Up</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                  <form method="POST" action="signup.php">
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <div class="mb-3">
        <label for="rollno" class="form-label">Roll No</label>
        <input type="text" class="form-control" id="rollno" name="rollno" required>
    </div>
    <div class="mb-3">
        <label for="section" class="form-label">Section</label>
        <input type="text" class="form-control" id="section" name="section" required>
    </div>
    <button type="submit" class="btn btn-success w-100">Sign Up</button>
</form>

                  </div>
              </div>
          </div>
      </div>

    <!-- Main Content -->
    <div class="container mt-5">
        <div class="text-center">
            <h1>Welcome to the School Management System</h1>
            <p class="lead">Manage all aspects of the school efficiently in one place.</p>
        </div>

        <!-- Features Section -->
        <div class="row mt-5">
            <div class="col-md-3 text-center">
                <div class="feature-box">
                    <h3>Library</h3>
                    <p>Access books, journals, and other study materials.</p>
                    <a href="library.php" class="btn btn-primary">Explore</a>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-box">
                    <h3>Laboratory</h3>
                    <p>Explore experiments and laboratory resources.</p>
                    <a href="labrotary.php" class="btn btn-primary">Explore</a>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-box">
                    <h3>Administration</h3>
                    <p>Manage student data, faculty, and school operations.</p>
                    <a href="administration.php" class="btn btn-primary">Explore</a>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="feature-box">
                    <h3>Examination</h3>
                    <p>Track exams, results, and schedules.</p>
                    <a href="examination.html" class="btn btn-primary">Explore</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
